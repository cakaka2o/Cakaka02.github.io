const fileInput = document.getElementById('fileInput');
const audioPlayer = document.getElementById('audioPlayer');
const videoPlayer = document.getElementById('videoPlayer');
const imageViewer = document.getElementById('imageViewer');
const playPauseBtn = document.getElementById('playPauseBtn');
const skipBackBtn = document.getElementById('skipBackBtn');
const skipForwardBtn = document.getElementById('skipForwardBtn');
const currentTimeDisplay = document.getElementById('currentTime');
const durationDisplay = document.getElementById('duration');
const controlsDiv = document.querySelector('.controls');

// Formatear tiempo en minutos:segundos
function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

// Actualizar duración total y tiempo actual
function updateTime() {
  let player = null;
  if (audioPlayer.style.display !== 'none') {
    player = audioPlayer;
  } else if (videoPlayer.style.display !== 'none') {
    player = videoPlayer;
  }
  if (player && player.duration) {
    currentTimeDisplay.textContent = formatTime(player.currentTime);
    durationDisplay.textContent = formatTime(player.duration);
  }
}

// Reproducir o pausar el medio activo
function togglePlayPause() {
  let player = null;
  if (audioPlayer.style.display !== 'none') {
    player = audioPlayer;
  } else if (videoPlayer.style.display !== 'none') {
    player = videoPlayer;
  } else {
    return;
  }
  
  if (player.paused) {
    player.play();
    playPauseBtn.querySelector('img').src = "assets/iconos/a555620633d5575e46298dc0648992d9-icono-de-circulo-de-boton-de-pausa.png";
  } else {
    player.pause();
    playPauseBtn.querySelector('img').src = "assets/iconos/botón-reproducir.jpg";
  }
}

// Saltar 10 segundos hacia atrás
function skipBack() {
  let player = null;
  if (audioPlayer.style.display !== 'none') {
    player = audioPlayer;
  } else if (videoPlayer.style.display !== 'none') {
    player = videoPlayer;
  } else {
    return;
  }
  player.currentTime = Math.max(0, player.currentTime - 10);
}

// Saltar 10 segundos hacia adelante
function skipForward() {
  let player = null;
  if (audioPlayer.style.display !== 'none') {
    player = audioPlayer;
  } else if (videoPlayer.style.display !== 'none') {
    player = videoPlayer;
  } else {
    return;
  }
  player.currentTime = Math.min(player.duration, player.currentTime + 10);
}

// Doble clic en el video: izquierda retrocede, derecha adelanta
videoPlayer.addEventListener('dblclick', (event) => {
  const rect = videoPlayer.getBoundingClientRect();
  const x = event.clientX - rect.left;
  if (x < rect.width / 2) {
    skipBack();
  } else {
    skipForward();
  }
});

// Cargar archivo seleccionado
fileInput.addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (!file) return;
  const url = URL.createObjectURL(file);
  
  // Ocultar todos los reproductores
  audioPlayer.style.display = 'none';
  videoPlayer.style.display = 'none';
  imageViewer.style.display = 'none';
  controlsDiv.style.display = 'flex';
  
  if (file.type.startsWith('audio')) {
    audioPlayer.src = url;
    audioPlayer.style.display = 'block';
    playPauseBtn.querySelector('img').src = "assets/iconos/botón-reproducir.jpg";
  } else if (file.type.startsWith('video')) {
    videoPlayer.src = url;
    videoPlayer.style.display = 'block';
    playPauseBtn.querySelector('img').src = "assets/iconos/botón-reproducir.jpg";
  } else if (file.type.startsWith('image')) {
    imageViewer.src = url;
    imageViewer.style.display = 'block';
    // Ocultar controles para imagen
    controlsDiv.style.display = 'none';
  }
});

// Eventos de los botones
playPauseBtn.addEventListener('click', togglePlayPause);
skipBackBtn.addEventListener('click', skipBack);
skipForwardBtn.addEventListener('click', skipForward);

// Actualizar tiempo cada medio segundo
setInterval(updateTime, 500);